﻿namespace TallerMecanico.Core.QueryFilters
{
    public class VehicleQueryFilter
    {
        public string? Plate { get; set; }
        public string? Brand { get; set; }
        public int? ClientId { get; set; }
    }
}
