﻿using AutoMapper;
using TallerMecanico.Core.Dtos;
using TallerMecanico.Core.Interfaces;
using TallerMecanico.Core.Entities;
using TallerMecanico.Core.Exceptions;

namespace TallerMecanico.Infrastructure.Services
{
    public class ServiceService : IServiceService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public ServiceService(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        // Obtener servicios por vehículo
        public async Task<IReadOnlyList<ServiceResponse>> GetByVehicleAsync(int idVehicle)
        {
            var list = await _unitOfWork.Services.GetServicesByVehicleAsync(idVehicle); // Usando Dapper para obtener los servicios por vehículo
            return _mapper.Map<List<ServiceResponse>>(list);
        }

        // Crear un servicio
        public async Task<int> CreateAsync(CreateServiceRequest dto)
        {
            var vehicle = await _unitOfWork.Vehicles.GetByIdAsync(dto.IdVehicle);
            if (vehicle is null)
                throw new BusinessException("IdVehicle no existe", "VEHICLE_NOT_FOUND", 404);

            if (!string.IsNullOrWhiteSpace(dto.Description) && dto.Description.Length > 200)
                throw new BusinessException("Descripción excede 200 caracteres", "DESCRIPTION_TOO_LONG", 400);

            if (dto.DateService.HasValue && dto.DateService.Value > DateTime.UtcNow.Date)
                throw new BusinessException("DateService no puede ser futura", "FUTURE_SERVICE_DATE", 400);

            var entity = _mapper.Map<WorkshopService>(dto);
            await _unitOfWork.Services.AddAsync(entity);
            await _unitOfWork.SaveChangesAsync();
            return entity.IdService;
        }
    }
}
