using Microsoft.EntityFrameworkCore;
using FluentValidation;
using FluentValidation.AspNetCore;
using TallerMecanico.Api.Mapping;
using TallerMecanico.Core.Interfaces;
using TallerMecanico.Infrastructure.Data;
using TallerMecanico.Infrastructure.Repositories;
using TallerMecanico.Infrastructure.Services;
using TallerMecanico.Api.Middleware;
using TallerMecanico.Infrastructure.Filters;
using Microsoft.Extensions.Configuration;
using System.Data;
using Dapper;
using MySqlConnector;

var builder = WebApplication.CreateBuilder(args);

// Configuraci�n de validadores
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<TallerMecanico.Api.Validation.ClientCreateValidator>();

// Configuraci�n de AutoMapper
builder.Services.AddAutoMapper(typeof(MappingProfile));

// Configuraci�n de los servicios
builder.Services.AddScoped<IClientService, ClientService>();
builder.Services.AddScoped<IVehicleService, VehicleService>();
builder.Services.AddScoped<IServiceService, ServiceService>();

// Configuraci�n de los repositorios con Dapper
builder.Services.AddScoped<IClientRepository, ClientRepository>();
builder.Services.AddScoped<IVehicleRepository, VehicleRepository>();
builder.Services.AddScoped<IServiceRepository, ServiceRepository>();

// Configuraci�n de UnitOfWork
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

// Configuraci�n de Dapper Connection Factory
builder.Services.AddScoped<IDbConnection>(provider =>
{
    var connectionString = builder.Configuration.GetConnectionString("Default");
    return new MySqlConnection(connectionString);
});

// Middleware
builder.Services.AddTransient<ExceptionMiddleware>();

// Configuraci�n de Swagger
builder.Services.AddSwaggerGen();
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();
app.UseMiddleware<ExceptionMiddleware>();
app.MapControllers();
app.Run();
