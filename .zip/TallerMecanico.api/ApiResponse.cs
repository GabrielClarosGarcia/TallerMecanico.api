﻿namespace TallerMecanico.Api
{
    public class ApiResponse<T>
    {
        public bool Success { get; set; }  // Indica si la respuesta fue exitosa
        public T Data { get; set; }        // Datos devueltos en la respuesta
        public string? Message { get; set; } // Mensaje asociado a la respuesta
        public string? ErrorCode { get; set; } // Código de error, si corresponde

        public ApiResponse(bool success, T data, string? message = null, string? errorCode = null)
        {
            Success = success;
            Data = data;
            Message = message;
            ErrorCode = errorCode;
        }
    }
}
